#include "sort.h"

void insert_sort(int r[], int n)
{
    int i, j, tmp;
    
    for (i = 1; i < n; i++) {
        tmp = r[i];
        for (j = i; j > 0; j--) {
            if (r[j - 1] > tmp)
                r[j] = r[j - 1];
            else 
                break;
        }
        r[j] = tmp;
    }
}

void bin_insert_sort(int r[], int n)
{
    int i, j, tmp, low, mid, high;
    
    for (i = 1; i < n; i++) {
        tmp = r[i];
        low = 0;
        high = i;
        while (low < high) {
            mid = (low + high) / 2;
            if (r[mid] <= tmp)
                low = mid + 1;
            else
                high = mid;
        }
        for (j = i; j > high; j--) 
            r[j] = r[j - 1];
        r[j] = tmp;
    }
}

void shell_insert(int r[], int n, int d)
{
    int i, j, tmp;
    for (i = d; i < n; i++) {
        tmp = r[i];
        for (j = i; j >= d; j -= d) {
            if (r[j - d] > tmp)
                r[j] = r[j - d];
            else
                break;
        }
        r[j] = tmp;
    }
}

void shell_sort(int r[], int n)
{
    int s, d;

    for (s = 1; (1 << s) < n; s++);
    s = s > 4 ? s - 3 : 1;

    for (; s > 0; s--) {
        d = (1 << s) - 1;
        shell_insert(r, n, d);
    }
}
