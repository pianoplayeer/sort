#include <stdio.h>
#include <stdlib.h>

void clib_sort(int r[], int n);

void insert_sort(int r[], int n);
void bin_insert_sort(int r[], int n);
void shell_sort(int r[], int n);

void bubble_sort(int r[], int n);
void bubble_sort_GOOD(int r[], int n);
void bubble_sort0(int r[], int n);
void quick_sort(int r[], int n);
void quick_sort0(int r[], int n);
void quick_sort0_p274(int r[], int n);
void quick_sort1(int r[], int n);
void quick_sort2(int r[], int n);
void quick_sort3(int r[], int n);

void select_sort(int r[], int n);
void heap_sort(int r[], int n);

void merge_sort(int r[], int n);
void merge_sort1(int r[], int n);
void merge_sort_r(int r[], int n);

void radix4_sort(int r[], int n);
void radix8_sort(int r[], int n);
void radix16_sort(int r[], int n);
void radix256_sort(int r[], int n);
void radix65536_sort(int r[], int n);

#define swap(a, b) do { \
    int t; \
    t = a; \
    a = b; \
    b = t; \
} while (0)

#define N0_STR  "64"  /* 当待排序列规模不大于N0时采用插入排序 */
extern int N0;
