#include "sort.h"

#if defined(_MSC_VER)

#pragma comment(linker, "/STACK:5000000")
#include <windows.h>

typedef __int64 s64;

s64 rdtsc(void)
{
	LARGE_INTEGER a;
	QueryPerformanceCounter(&a);
	return (s64)a.QuadPart;
}

#else

#include <unistd.h>
typedef signed long long s64;
/* rdtsc: read timestamp counter */
static s64 rdtsc(void)
{
	unsigned int lo, hi;
	__asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
	return ((s64)hi << 32) | lo;
}

#define Sleep(ms) usleep((ms) * 1000)

#endif


s64 tps; /* timestamp counter per second */

s64 get_tps(void)
{
     s64 t0 = rdtsc();
     Sleep(100);
     return (rdtsc() - t0) * 10;
}

#define SIZE (52 * 1024 * 1024)

int org[SIZE], data[SIZE], ans[SIZE];
int n;

void test(char *algorithm_name, void (*algorithm)(int r[], int n), int fast, char *comment)
{
    s64 t1, t2;
    int i;

    if (!fast && n > 1000000) { 
        printf("%20s,%7s, %s\n", algorithm_name, "-", comment);
	    return;
    }

    for (i = 0; i < n; i++)
        data[i] = org[i];

    t1 = rdtsc();
    (*algorithm)(data, n);
    t2 = rdtsc();
    
    printf("%20s,%7.0f, %s\n", algorithm_name, 1000.0 * (t2 - t1) / tps, comment);

    for (i = 0; i < n; i++) {
        if (data[i] != ans[i]) {
            printf("****** ERROR %d/%d: %d != %d\n", i, n, data[i], ans[i]);
            exit(1);
        }
    }
}

#define test_func(func, fast, comment) test(#func, func, fast, comment)

int N0;

int main(void)
{
    int i;

    N0 = atoi(N0_STR);
    tps = get_tps();

    for (n = 0; n < SIZE && scanf("%d", &org[n]) > 0; n++);

    printf("tps = %.3fM, SIZE = %d, n = %d\n", tps / 1e6, SIZE, n);
    
    for (i = 0; i < n; i++)
        ans[i] = org[i];
    clib_sort(ans, n);

    test_func(clib_sort,       1, "C语言标准库函数");

    test_func(insert_sort,     0, "直接插入排序");
    test_func(bin_insert_sort, 0, "二分插入排序");
    test_func(shell_sort,      1, "希尔排序(步长为2的s次方减一，s递减)");

    test_func(bubble_sort,     0, "冒泡排序");
    test_func(bubble_sort_GOOD,0, "冒泡排序(优化内层循环的边界)");
    test_func(bubble_sort0,    0, "冒泡排序(不考虑一趟扫描若无交换操作就提前结束)");
    test_func(quick_sort,      1, "快速排序的原始版本：以r[0]为支点二分区，待排序列正序或逆序时性能退化");
    test_func(quick_sort0,     1, "快速排序：待排序列规模较小(≤"N0_STR")时选用直接插入排序");
    test_func(quick_sort0_p274,1, "快速排序：待排序列规模较小(≤"N0_STR")时选用直接插入排序，分区算法参考教材p274");
    test_func(quick_sort1,     1, "快速排序：“三者取中”法选定支点，待排序列逆序时性能退化");
    test_func(quick_sort2,     1, "快速排序：选随机元素为支点，但有大量相等元素时性能退化");
    test_func(quick_sort3,     1, "快速排序：选随机元素为支点，三分区，有大量相等元素时性能不会退化");

    test_func(select_sort,     0, "直接选择排序");
    test_func(heap_sort,       1, "堆排序");
    
    test_func(merge_sort,      1, "两路归并排序");
    test_func(merge_sort1,     1, "两路归并排序，小规模(≤"N0_STR")数据用直接插入排序");
    test_func(merge_sort_r,    1, "两路归并排序的递归版本，小规模(≤"N0_STR")数据用直接插入排序");
    
    test_func(radix4_sort,     1, "基数排序：把整数看做16个4进制数字");
    test_func(radix8_sort,     1, "基数排序：把整数看做11个8进制数字");
    test_func(radix16_sort,    1, "基数排序：把整数看做8个16进制数字");
    test_func(radix256_sort,   1, "基数排序：把整数看做4个256进制数字");
    test_func(radix65536_sort, 1, "基数排序：把整数看做2个65536进制数字");
}
