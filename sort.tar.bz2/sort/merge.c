#include "sort.h"

/* 将src数组中从low到mid，mid到high两个有序片段合并成一个有序片段，
合并后结果放到dst数组的low到high处 */
static void merge(int src[], int dst[], int low, int mid, int high)
{
    int i, j, k;

    k = i = low;
    j = mid; 
    
    while (i < mid && j < high) {
        if (src[i] >= src[j]) 
            dst[k++] = src[j++];
        else
            dst[k++] = src[i++];
    }
    while (i < mid)
        dst[k++] = src[i++];

    while (j < high)
        dst[k++] = src[j++];
}

/* 将r中从low到high的这个片段分成两段，分别排序好之后的中间结果（两个有序片段）放在S，然后从S归并到T */
void sort_segment(int r[], int s[], int t[], int low, int high)
{
    if (r == t && high - low <= N0) 
        insert_sort(&r[low], high - low);
    else {
        int mid = (low + high) / 2;
        sort_segment(r, t, s, low, mid);
        sort_segment(r, t, s, mid, high);
        merge(s, t, low, mid, high);
    }
}

/* 归并排序(递归版) */
void merge_sort_r(int r[], int n)
{
    int *s;

    if ((s = (int *)malloc(sizeof(int) * n)) == NULL)
        return;
    sort_segment(r, s, r, 0, n);
    free(s);
}

/* 归并排序的“一趟”：src中的n个数据，从左到右每len个数据是有序的
   合并到dst后，从左到右每2*len个数据是有序的 */
#define trim(x, max) (x > max ? max : x)
void merge_pass(int src[], int dst[], int len, int n)
{
	int l, m, h;
      for (l = 0; l < n; l = h) {
    	    m = trim(l + len, n);
	    h = trim(m + len, n);
	    merge(src, dst, l, m, h);
	}   
}

void merge_sort(int r[], int n)
{
    int *s = (int *)malloc(n * sizeof(int));
	int len = 1;
	while (len < n) {
	   	merge_pass(r, s, len, n);
	   	len *= 2; 
    	merge_pass(s, r, len, n);
       	len *= 2;
	}    
    free(s);
}

void merge_sort1(int r[], int n)
{
    int *s = (int *)malloc(n * sizeof(int));
	int i, len = N0;

    for (i = 0; i < n; i += N0) 
        insert_sort(&r[i], trim(n - i, N0));

    while (len < n) {
	   	merge_pass(r, s, len, n);
	   	len *= 2; 
    	merge_pass(s, r, len, n);
       	len *= 2;
	}    
    free(s);
}
