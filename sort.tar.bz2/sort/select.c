#include "sort.h"

/* 简单选择排序 */
void select_sort(int r[], int n)
{
    int i, j, min;

    for (i = 0; i < n - 1; i++) {
        min = i;
        for (j = i + 1; j < n; j++) {
            if (r[j] < r[min])
                min = j;
        }
        swap(r[i], r[min]);
    }
}

/* r中有n个有效元素， 节点root的左子树右子树皆为堆， 调整后节点root为根的子树为堆 */
void heap_adjust(int r[], int root, int n)
{
    int tmp;
    int i, lchild, rchild, elder;

    tmp = r[root];
    for (i = root; (lchild = 2 * i + 1) < n; i = elder) {
        rchild = lchild + 1;
        if (rchild < n && r[lchild] < r[rchild])
            elder = rchild;
        else
            elder = lchild;
        if (tmp > r[elder])
            break;
        r[i] = r[elder];
    }
    r[i] = tmp;
}

/* 堆排序 */
void heap_sort(int r[], int n)
{
    int i;

    for (i = n / 2 - 1; i >= 0; i--) 
        heap_adjust(r, i, n);

    for (i = n - 1; i > 0; i--) {
        swap(r[0], r[i]);
        heap_adjust(r, 0, i);
    }
}

