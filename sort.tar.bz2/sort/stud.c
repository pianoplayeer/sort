#include <stdio.h>
#include <stdlib.h>


struct STUD {
    int id;
    char name[128];
};

#define N 128
struct STUD s[N];
int n = 0;

int compare(const void *a, const void *b)
{
    const struct STUD *sa = a, *sb = b;
    return sa->id > sb->id ? +1 : sa->id < sb->id ? -1 : 0;
}

int main(void)
{
    while (n < N && scanf("%d%s", &s[n].id, s[n].name) == 2)
        n++;
    qsort(s, n, sizeof(struct STUD), compare);

    for (int i = 0; i < n; i++)
        printf("%d %s\n", s[i].id, s[i].name);
}
