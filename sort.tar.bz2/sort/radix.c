#include "sort.h"

struct NODE {
    int key;
    struct NODE *next;
};

#define get_key(key, index, nbits) ((key >> (index * nbits)) & (rd - 1))

static void distribute(struct NODE *p, struct NODE *f[], struct NODE *e[], int index, int nbits)
{
    int i, rd = 1 << nbits;

    for (i = 0; i < rd; i++) 
        f[i] = NULL;

    for (; p != NULL; p = p->next) {
        i = get_key(p->key, index, nbits);
        if (f[i] == NULL)
            f[i] = e[i] = p;
        else {
            e[i]->next = p;
            e[i] = p;
        }
    }
}

static struct NODE *collect(struct NODE *f[], struct NODE *e[], int rd)
{
    struct NODE *front = NULL, *end = NULL;
    int i;

    for (i = 0; i < rd; i++) {
        if (f[i] == NULL) 
            continue;
        if (front == NULL) 
            front = f[i];
        else 
            end->next = f[i];
        end = e[i];
    }
    if (front != NULL)
        end->next = NULL;
    return front;
}

/* 基数排序: 组成一个整数的每个“数字”占nbits比特，“2的nbits次方”进制 */
void radix_sort(int r[], int n, int nbits)
{
    int i, rd = 1 << nbits, d = (32 + nbits - 1) / nbits;
    struct NODE **f, **e, *nd, *front;
    
    if (n < 2)
        return;

    f = (struct NODE **)malloc(sizeof(struct NODE *) * rd);
    e = (struct NODE **)malloc(sizeof(struct NODE *) * rd);
    nd = (struct NODE *)malloc(sizeof(struct NODE) * n);

    if (f == NULL || e == NULL || nd == NULL) {
        printf("内存申请失败, %d\n", (int)sizeof(struct NODE) * (n + 2 * rd));
        exit(1);
    }

    front = &nd[0];
    for (i = 0; i < n; i++) {
        nd[i].key = r[i];
        nd[i].next = &nd[i + 1];
    }
    nd[n - 1].next = NULL;

    for (i = 0; i < d; i++) {
        distribute(front, f, e, i, nbits);
        front = collect(f, e, rd);
    }

    for (i = 0; front != NULL; front = front->next)
        r[i++] = front->key;

    free(f);
    free(e);
    free(nd);
}

void radix4_sort(int r[], int n)
{
    radix_sort(r, n, 2);
}

void radix8_sort(int r[], int n)
{
    radix_sort(r, n, 3);
}

void radix16_sort(int r[], int n)
{
    radix_sort(r, n, 4);
}

void radix256_sort(int r[], int n)
{
    radix_sort(r, n, 8);
}

void radix65536_sort(int r[], int n)
{
    radix_sort(r, n, 16);
}
