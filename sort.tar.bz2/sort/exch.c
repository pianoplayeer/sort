#include "sort.h"

int comp_int(const void *a, const void *b)
{
    int ia = *(int *)a, ib = *(int *)b;
    return ia > ib ? +1 : ia < ib ? -1 : 0;
}

void clib_sort(int r[], int n)
{
    qsort(r, n, sizeof(int), comp_int);
}

void bubble_sort(int r[], int n)
{
    int i, j, sorted = 0;
    for (i = 1; i < n && !sorted; i++) {
        sorted = 1;
        for (j = 0; j < n - i; j++) {
           if (r[j] > r[j + 1]) {
               swap(r[j], r[j + 1]);
               sorted = 0;
           }
        }
    }
}

void bubble_sort_GOOD(int r[], int n)
{
    int i, j, sorted = 0;
    for (i = n - 1; i > 0 && !sorted; i--) {
        sorted = 1;
        for (j = 0; j < i; j++) {
           if (r[j] > r[j + 1]) {
               swap(r[j], r[j + 1]);
               sorted = 0;
           }
        }
    }
}

void bubble_sort0(int r[], int n)
{
    int i, j;
    for (i = 1; i < n; i++) {
        for (j = 0; j < n - i; j++) {
           if (r[j] > r[j + 1]) 
               swap(r[j], r[j + 1]);
        }
    }
}

int partition(int r[], int n)
{
    int low = 0, high = n - 1, tmp;

    tmp = r[0];
    
    while (low < high) {
        while (low < high && r[high] >= tmp)
            high--;

        if (low < high) {
            r[low] = r[high];
            low++;
        }
        
        while (low < high && r[low] <= tmp)
            low++;

        if (low < high) {
            r[high] = r[low];
            high--;
        }
    }    

    r[low] = tmp;

    return low;
}

int partition_p274(int r[], int n)
{
    int low = 0, high = n - 1, tmp;

    tmp = r[0];
    
    while (low < high) {
        while (low < high && r[high] >= tmp)
            high--;
        r[low] = r[high];
        while (low < high && r[low] <= tmp)
            low++;
        r[high] = r[low];
    }    

    r[low] = tmp;

    return low;
}

void quick_sort(int r[], int n)
{
	if (n < 2)
		return;

	int k = partition(r, n);

	quick_sort(r, k);
	quick_sort(&r[k + 1], n - k - 1);
}

void quick_sort0(int r[], int n)
{
	if (n <= N0) 
		return insert_sort(r, n);

	int k = partition(r, n);

    if (k < n / 2) {
		quick_sort0(r, k);
		quick_sort0(&r[k + 1], n - k - 1);
	} else {
		quick_sort0(&r[k + 1], n - k - 1);
		quick_sort0(r, k);
	}
}

void quick_sort0_p274(int r[], int n)
{
	if (n <= N0) 
		return insert_sort(r, n);

	int k = partition_p274(r, n);

    if (k < n / 2) {
		quick_sort0(r, k);
		quick_sort0(&r[k + 1], n - k - 1);
	} else {
		quick_sort0(&r[k + 1], n - k - 1);
		quick_sort0(r, k);
	}
}

void quick_sort1(int r[], int n)
{
	if (n <= N0) 
		return insert_sort(r, n);

    // ����ȡ��
    int a, b, c;
	if (r[0] > r[n - 1]) {
		a = n - 1;
		b = 0;
	} else {
		a = 0;
		b = n - 1;
	}
	c = n / 2;
	if (r[c] < r[b])
		b = r[a] > r[c] ? a : c;
	//printf("n=%d %d %d %d [%d]\n", n, r[0], r[n / 2], r[n - 1], r[b]);
	swap(r[b], r[0]);

	int k = partition(r, n);

	if (k < n / 2) {
		quick_sort1(r, k);
		quick_sort1(&r[k + 1], n - k - 1);
	} else {
		quick_sort1(&r[k + 1], n - k - 1);
		quick_sort1(r, k);
	}
}

void quick_sort2(int r[], int n)
{
    int k;
    if (n <= N0) 
        return insert_sort(r, n);

    // �����ѡһ��Ԫ����֧��
    k = rand() % n;
    swap(r[0], r[k]);

    k = partition(r, n);
    
    if (k < n / 2) {
        quick_sort2(r, k);
        quick_sort2(&r[k + 1], n - k - 1);
    } else {
        quick_sort2(&r[k + 1], n - k - 1);
        quick_sort2(r, k);
    }
}

#define minval(a, b) (a > b ? b : a)

// ������
void partition3(int r[], int n, int *eq_ptr, int *gt_ptr)
{
    int i = 1, j = n, p = 1, q = n, v = r[0];
    int m, k;

    v = r[0];
    while (i < j) {
        while (i < j && r[i] <= v) {
            if (r[i] == v) {
                swap(r[i], r[p]);
                p++;
            }
            i++;
        }
        while (i < j && r[j - 1] >= v) {
            if (r[j - 1] == v) {
                swap(r[j - 1], r[q - 1]);
                q--;
            }
            j--;
        }
        if (i < j)
            swap(r[i], r[j - 1]);
    }

    m = minval(i - p, p);
    for (k = 0; k < m; k++)
        swap(r[k], r[i - 1 - k]);
    *eq_ptr = i - p;

    m = minval(n - q, q - j);
    for (k = 0; k < m; k++)
        swap(r[j + k], r[n - 1 - k]);
    *gt_ptr = j + (n - q); 
}

void quick_sort3(int r[], int n)
{
    int k, eq, gt;
    if (n <= N0) 
        return insert_sort(r, n);

    k = rand() % n;
    swap(r[0], r[k]);

    partition3(r, n, &eq, &gt);
    
    if (eq < n - gt) {
        quick_sort3(r, eq);
        quick_sort3(&r[gt], n - gt);
    } else {
        quick_sort3(&r[gt], n - gt);
        quick_sort3(r, eq);
    }
}
